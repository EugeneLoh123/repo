// Author: Eugene Loh
//This is my original work
import java.util.Scanner;

/**
   This program demonstrates how numeric types and
   operators behave in Java.
*/

public class NumericTypes
{
   public static void main (String [] args)
   {
      Scanner scanner = new Scanner(System.in);

      // Identifier declarations
      final int NUMBER = 2 ;        // Number of scores
      final int SCORE1 = 100;       // First test score
      final int SCORE2 = 95;        // Second test score
      final int BOILING_IN_F = 212; // Boiling temperature
      int fToC;                     // Temperature Celsius
      double average;               // Arithmetic average
      String output;                // Line of output

      String firstName;
      String lastName;
      char firstInitial;
      double diameter;
      double radius;
      double volume;

      // Find an arithmetic average.
      average = (double)(SCORE1 + SCORE2) / NUMBER;
      output = SCORE1 + " and " + SCORE2 + " have an average of " + average;
      System.out.println(output);

      // Convert Fahrenheit temperature to Celsius.
      fToC = (5 * (BOILING_IN_F - 32)) / 9;
      output = BOILING_IN_F + " in Fahrenheit is " + fToC + " in Celsius.";
      System.out.println(output);
      System.out.println();      // To leave a blank line

      // ADD LINES FOR TASK #2 HERE
      System.out.println("Enter your first name: ");
      firstName = scanner.nextLine();
      System.out.println("Enter your last name: ");
      lastName = scanner.nextLine();
      String fullName = firstName + " " + lastName;
      System.out.println("Your full name is: " + fullName);

      System.out.println();      // To leave a blank line

      // ADD LINES FOR TASK #3 HERE
      firstInitial = firstName.charAt(0);
      System.out.println("Your first initial is: " + firstInitial);
      fullName = fullName.toUpperCase();
      System.out.println("Your full name fully uppercased is: " + fullName + ". There are " + fullName.length() + " characters including the space in your name.");

      System.out.println();      // To leave a blank line

      // ADD LINES FOR TASK #4 HERE
      System.out.println("Enter a diameter of a sphere: ");
      diameter = scanner.nextDouble();
      radius = diameter / 2;
      volume = (4 * Math.PI * (Math.pow(radius, 3))) / 3;
      System.out.println("The diameter is: " + diameter + ". The radius is: " + radius + ". The volume is: " + volume + ".");
   }
}