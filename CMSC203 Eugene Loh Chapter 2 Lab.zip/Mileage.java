//Author: Eugene Loh
//This is my original work
/** The purpose of this program is to calculate the mileage based on the users inputs. My name is Eugene Loh. Today's date is 09/18/26. 

 */

import java.util.Scanner;

public class Mileage {

	public static void main(String[] args) {
		
		//Create new scanner object to run input by user
		Scanner scanner = new Scanner(System.in);
		
		//Represents the miles driven by user
		double miles;
		//Represents the number of gallons used by the user
		double gallons;
		//Represents the miles per gallon
		double mpg;
		
		//Tell user what the program is used for
		System.out.println("This program will calculate mileage.");
		
		//Prompt user for miles driven and stores input into miles
		System.out.println("Enter miles driven: ");
		miles = scanner.nextDouble();
		
		//Prompt user for gallons used and stores input into gallons
		System.out.println("Enter gallons used: ");
		gallons = scanner.nextDouble();
		
		//Calculates miles per gallons by using the input given by the user. Prints out the result.
		mpg = miles / gallons;
		System.out.println("Your miles per gallon is: " + mpg);
		
		//The purpose of the calculation is to tell the user what their miles per gallon is.

	}

}
